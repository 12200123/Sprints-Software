<?php
$dbHost = 'Localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'SysSec';
try {
    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
} catch (mysqliException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>