<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
<?php require ("conexao.php"); ?>
    <div class="main-login">
        <div class="left-login">
            <h1>Nome da empresa<br>Por favor, faça seu login!</h1>
            <img src="computador.svg" class="left-login-image" alt="Animação">
        </div>
        <div class="right-login">
            <div class="card-login">
                <form action="login.php" method="POST">
                <h1>LOGIN</h1>
                <div class="textfield">
                    <label for="usuario">Usuário</label>
                    <input type="text" name="usuario" placeholder="Usuário">
                </div>
                <div class="textfield">
                    <label for="senha">Senha</label>
                    <input type="password" name="senha" placeholder="Senha">
                </div>
                <input class="btn-login" type="submit" name="submit" value="Login">
            </form>
            </div>
        </div>
    </div>
</body>
</html>